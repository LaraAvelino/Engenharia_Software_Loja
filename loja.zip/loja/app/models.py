from django.db import models

class Categoria(models.Model):
    nome = models.CharField(max_length=50)

    def _str_(self):
        return self.nome

class Produto(models.Model):
    nome = models.CharField(max_length=50)
    categoria = models.ForeignKey(Categoria,
                                 on_delete=models.CASCADE)
    preco = models.PositiveIntegerField()

    def _str_(self):
        return f'{self.categoria} {self.nome}'

